package lista_semplice;

public class Studente {
	
	private String nominativo;
	private String sesso;
	private int altezza;
	private String serieTv;

	public Studente(String nominativo, String sesso, int altezza, String serieTv) {
		
		this.nominativo = nominativo;
		this.sesso = sesso;
		this.altezza = altezza;
		this.serieTv = serieTv;
	}

	public String getNominativo() {
		return nominativo;
	}

	public void setNominativo(String nominativo) {
		this.nominativo = nominativo;
	}

	public String getSesso() {
		return sesso;
	}

	public void setSesso(String sesso) {
		this.sesso = sesso;
	}


	public int getAltezza() {
		return altezza;
	}

	public void setAltezza(int altezza) {
		this.altezza = altezza;
	}

	public String getSerieTv() {
		return serieTv;
	}

	public void setSerieTv(String serieTv) {
		this.serieTv = serieTv;
	}

	@Override
	public String toString() {
		return "Studente [nominativo=" + nominativo + ", sesso=" + sesso + ", altezza=" + altezza
				+ ", serieTv=" + serieTv + "]";
	}
	
}
