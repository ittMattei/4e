package lista_semplice;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class LeggiCSV {
    public static void main(String[] args) {
        String csvFile = "C:\\Users\\ProFP\\4E.csv";
        String line = "";
        String csvSeparator = ",";
        
        //creo festa
       Classe quartaE = new Classe();
        
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            while ((line = br.readLine()) != null) {
                String[] record = line.split(csvSeparator);
                // fai qualcosa con il record letto dal file
               // System.out.println(record[1]); // esempio: stampa il primo campo
                
                //data_ora - mail - sesso - altezza - serieTv
                quartaE.inserisciInTesta(new Studente(record[1],record[2],Integer.parseInt(record[3]),record[4]));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        quartaE.visitaLista();
        Studente dummy = new Studente("pino","gino",123,"pino");
        quartaE.inserisciInCoda(dummy);
        quartaE.inserisciInPosizione(dummy, 3);
        
        quartaE.visitaLista();
        
    }
}
