package lista_semplice;

public class Nodo {
	
	private Studente info;
	private Nodo link;
	
	public Nodo(Studente persona) {
		info = persona;
		link = null;
		
	}
	public Studente getInfo() {
		return info;
	}

	public void setLink(Nodo link) {
		this.link = link;
	}
	
	public Nodo getLink() {
		return link;
	}
}
