package lista_semplice;

public class Classe {
	
	private Nodo head;
	private int elementi;
	
	public Classe() {
		head = null;
		elementi = 0;
	}
	
	public void visitaLista() {
		Nodo p = head;
		
		System.out.println("Inizio:");
		while(p != null) {
			System.out.println(p.getInfo().toString());
			p = p.getLink(); 
		}
	}
	
	//metodo unico per la creazione dei nodi, passo contenuto informativo e link al successivo
	private Nodo creaNodo(Studente s,Nodo link) {
		Nodo p = new Nodo(s);
		p.setLink(link);
		return p;
	}
	
	public void inserisciInTesta(Studente x) {
		
		Nodo p = creaNodo(x,head);
		head = p;
		elementi++;
		return;
	}
	
	public void inserisciInCoda(Studente y) {
		//creo nodo per scandire la lista
		Nodo p = head;
		//istanzio nodo con campo link nullo
		Nodo n = creaNodo(y,null);
		
		//questo ciclo si posiziona sull'ultimo elemento
		while(p.getLink()!=null) {
			p = p.getLink();
		}
		
		//imposto link dell'ultimo della lista con nuovo nodo
		p.setLink(n);
		
		elementi++;
		return;
	}
	
	public void inserisciInPosizione(Studente y, int pos) {
				//creo nodo per scandire la lista
				Nodo p = head;
				
				//questo ciclo si posiziona sull' elemento in psizione pos
				for(int i=1; i<pos-1; i++) {
					p = p.getLink();
				}
				
				//prima impostare link del nuovo al successivo
				Nodo n = creaNodo(y,p.getLink());
				
				//poi impostare link del precedente al nuovo
				p.setLink(n);
				
				elementi++;
				return;
	}
	
	public Nodo getHead() {
		return head;
	}
	
	public int getElementi() {
		return elementi;
	}
}
