/**
 * 
 */
/**
 * @author ProFP
 *
 */
module chat {
}