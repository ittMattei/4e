package time_client;
import java.net.*;
import java.io.*;

public class TimeClient {
	private String server_name;
	private int server_port;
	
	public TimeClient(String server, int port) throws IOException{
		server_name = server;
		server_port = port;
	}
	public String getTime() throws SocketTimeoutException, IOException{
		InputStream stream;
		String fragment;
		int n;
		String datetime;
		byte[] buffer = new byte[1024];
		
		Socket client_socket = new Socket();
		System.out.println("inizializzo socket");
		
		InetSocketAddress server_address = new InetSocketAddress(server_name,server_port);
		client_socket.setSoTimeout(1000);
		client_socket.connect(server_address,1000);
		System.out.println("connesso al socket");
		stream = client_socket.getInputStream();
		
		datetime="";
		while((n=stream.read(buffer))!=-1) {
			fragment = new String(buffer,0,n,"ISO-8859-1");
			datetime += fragment;
			System.out.println("leggo frammenti..");
		}
		//stream.close(); istruzione che genera errori
		client_socket.shutdownInput();
		client_socket.close();
		
		System.out.println("chiudo socket e ritorno data");
		return datetime;
	}
	public static void main(String args[]) {
		String server;
		int port;
		String datetime;
		TimeClient client;
		if(args.length!=2) {
			System.err.println("Argomenti errati");
			return;
		}
		else {
			server = args[0];
			port = Integer.parseInt(args[1]);
			System.out.println(server +" "+ port);
		}
		try {
			client = new TimeClient(server,port);
			datetime = client.getTime();
			System.out.println(datetime);
			}catch(SocketTimeoutException e) {e.printStackTrace();}
		catch(IOException e) {e.printStackTrace();}

	}

}
