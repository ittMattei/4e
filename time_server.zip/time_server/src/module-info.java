/**
 * 
 */
/**
 * @author ProFP
 *
 */
module time_server {
}