package time_server;
import java.net.*;
import java.io.*;
import java.util.*;


public class TimeServer extends Thread{
	private ServerSocket server;
	
	public TimeServer(int port) throws IOException{
		server = new ServerSocket(port);
		server.setSoTimeout(1000);
	}
		public void run() {
			Socket connection = null;
			while(!Thread.interrupted()) {
				try {
					System.out.println("attendo..");
				connection = server.accept();
				System.out.println("..fatta accept");
				OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream(),"ISO-8859-1");
				Date now = new Date();
				System.out.println("generata data");
				out.write(now.toString()+"\r\n");
				out.flush();
				out.close();
				System.out.println("chiusura socket");
				connection.shutdownOutput();
				connection.close();
				
				}catch(SocketTimeoutException e) {}
				catch(IOException e) {}
				finally {
					if(connection !=null) {
						try {
							connection.shutdownOutput();
							connection.close();
						}catch(IOException e) {}
					}
				}
		}
		
	
		try {
			server.close();
		}catch(IOException e) {}
		}
		
		public static void main(String[] args) {
		
		try {
			
			TimeServer time_server = new TimeServer(12345);
			time_server.start();
			System.in.read();
			time_server.interrupt();
			time_server.join();
			
		}catch(IOException e) {e.printStackTrace();}
		catch(InterruptedException e) {System.err.println("Errore2!");}
		

	}

}
